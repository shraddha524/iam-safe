package com.example.iamsafe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class TipsToEscapeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips_to_escape);
        // Retrieve the tips, you can implement your own logic here
        String tips = retrieveTips();

        // Find the TextView in the layout
        TextView tipsTextView = findViewById(R.id.tipsTextView);

        // Set the tips text
        tipsTextView.setText(tips);
    }

    // Method to retrieve the tips, you can implement your own logic here
    private String retrieveTips() {
        // Retrieve the tips from a data source or any other means
        String tips = "Here are some tips to escape from threats:\n\n"
                + "- Stay calm and assess the situation\n"
                + "- Trust your instincts\n"
                + "- Look for escape routes\n"
                + "- Avoid confrontation if possible\n"
                + "- Use verbal assertiveness or self-defense techniques if necessary\n"
                + "- Seek help from others or nearby authorities";

        return tips;

    }
}
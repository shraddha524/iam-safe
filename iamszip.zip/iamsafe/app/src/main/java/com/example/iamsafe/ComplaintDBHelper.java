package com.example.iamsafe;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ComplaintDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "complaints.db";
    private static final int DATABASE_VERSION = 1;

    public ComplaintDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE complaints (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String dropTableQuery = "DROP TABLE IF EXISTS complaints";
        db.execSQL(dropTableQuery);
        onCreate(db);
    }
}
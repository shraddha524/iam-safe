package com.example.iamsafe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PoliceHomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_police_home);
    }
}